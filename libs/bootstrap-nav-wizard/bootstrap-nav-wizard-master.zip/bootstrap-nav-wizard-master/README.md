bootstrap-nav-wizard
====================

Nav Wizard Component for Bootstrap 3

See demo [here](http://acornejo.github.io/bootstrap-nav-wizard/)

All credit goes to [zzullick](https://github.com/zzullick).
